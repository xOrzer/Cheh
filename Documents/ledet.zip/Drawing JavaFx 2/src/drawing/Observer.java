package drawing;

public interface Observer {
    public void actualiser(Observable o);
}
