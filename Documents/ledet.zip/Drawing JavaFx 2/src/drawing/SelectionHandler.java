package drawing;

import javafx.scene.input.MouseEvent;

import java.util.ArrayList;

public class SelectionHandler {
    private DrawingPane drawingPane;

    private double orgSceneX;
    private double orgSceneY;
    private double orgTranslateX;
    private double orgTranslateY;

    private ArrayList<IShape> selectedShape;

    public SelectionHandler(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
        drawingPane.setOnMousePressed(this);
        drawingPane.setOnMouseDragged(this);
        drawingPane.setOnMouseReleased(this);
    }

    public void addAndRemove(IShape shape){

    }

    @Override
    public void handle(MouseEvent event) {

        if (event.getEventType().equals(MouseEvent.MOUSE_PRESSED)) {
            orgSceneX = event.getSceneX();
            orgSceneY = event.getSceneY();


            for (IShape shape : selectedShape) {
                if (shape.isOn(event.getX(), event.getY())) {
                    selectedShape = shape;
                    break;
                }
            }

            orgTranslateX = selectedShape == null ? 0 : selectedShape.getTranslateX();
            orgTranslateY = selectedShape == null ? 0 : selectedShape.getTranslateY();

        }

        if (event.getEventType().equals(MouseEvent.MOUSE_DRAGGED)) {
            if (selectedShape.size() == 0) {
                return;
            }

            double offsetX = event.getSceneX() - orgSceneX;
            double offsetY = event.getSceneY() - orgSceneY;
            double newTranslateX = orgTranslateX + offsetX;
            double newTranslateY = orgTranslateY + offsetY;

            for (IShape shape : selectedShape) {
                shape.offset(newTranslateX, newTranslateY);
            }

        }

        if (event.getEventType().equals(MouseEvent.MOUSE_RELEASED)) {
            selectedShape = null;
        }
    }

}
