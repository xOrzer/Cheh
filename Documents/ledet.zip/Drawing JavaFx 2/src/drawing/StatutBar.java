package drawing;

import javafx.scene.layout.HBox;
import javafx.scene.control.Label;

public class StatutBar extends HBox implements Observer{
    public Label label;
    public Label value;

    public StatutBar() {
        this.label = new Label("shape(s)");
        this.value = new Label("0");
    }

    public void actualiser(Observable o)
    {
        if(o instanceof DrawingPane)
        {
            DrawingPane g = (DrawingPane) o;
            this.value.setText( Integer.toString( g.getShapeNumber() ));
        }
    }
}
