/******************************************************
 * Abstract class for the initialization of a solution
 */
abstract public class Init {
    public Init() {
    }

    abstract public void init(Solution solution) ;
}
