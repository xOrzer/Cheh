package drawing;

public class Arthur extends Exception {

    public Arthur(){
        super();
    }

    public Arthur(String s){
        super(s);
    }

}
