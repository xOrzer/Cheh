package lsg.bags;

public class MediumBag extends Bag{

    public MediumBag() {
        super(40);
    }

}
