package lsg.exceptions;

public class StaminaEmptyException extends Exception{

    public StaminaEmptyException() {
        super("No stamina !") ;
    }
}
