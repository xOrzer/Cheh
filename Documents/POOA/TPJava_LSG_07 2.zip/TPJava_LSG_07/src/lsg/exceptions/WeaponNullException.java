package lsg.exceptions;

public class WeaponNullException extends Exception {

    public WeaponNullException() {
        super("No Weapon !");
    }
}
