package lsg.exceptions;

public class BagNullException extends Exception {

    public BagNullException() {
        super("No Bag !");
    }
}
