package lsg.consumables.drinks;

public class Whisky extends Drink{

    public Whisky(){
        super("12 years old Oban", 150) ;
    }
}
