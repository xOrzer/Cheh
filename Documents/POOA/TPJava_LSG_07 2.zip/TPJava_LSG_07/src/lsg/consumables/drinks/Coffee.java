package lsg.consumables.drinks;

public class Coffee extends Drink {

    public Coffee(){
        super("Hot Grandmother Coffee", 10) ;
    }

}
