package lsg.consumables.drinks;

public class Wine extends Drink{

    public Wine(){
        super("Pomerol 2008", 30) ;
    }

}
