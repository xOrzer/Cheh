package drawing;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class SelectionHandler implements EventHandler<MouseEvent> {


    public SelectionHandler(){

    }

    @Override
    public void handle(MouseEvent event) {

    }


}
