package org.ulco;

public class ID {
    static public int ID = 0;
}