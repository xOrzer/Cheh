package org.ulco;

import java.util.Vector;

public class GraphicsObjects extends Vector <GraphicsObject> {
    public GraphicsObjects() {

    }
}
