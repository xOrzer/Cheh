package drawing;

import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

import java.util.List;

public class ToolBar extends HBox implements Observer{

    private Button clearButton;
    private Button rectangleButton;
    private Button circleButton;
    private Button triangleButton;
    private Button removeButton;
    private Button groupButton;
    private Button degroupButton;

    public ToolBar(DrawingPane drawingPane) {
        clearButton = new Button("Clear");
        // clearButton.setOnAction(event -> drawingPane.clear());
        clearButton.addEventFilter(ActionEvent.ACTION, new ClearButtonHandler(drawingPane));
        rectangleButton = new Button("Rectangle");
        rectangleButton.addEventFilter(ActionEvent.ACTION, new RectangleButtonHandler(drawingPane));
        circleButton = new Button("Circle");
        circleButton.addEventFilter(ActionEvent.ACTION, new EllipseButtonHandler(drawingPane));
        triangleButton = new Button("Triangle");
        triangleButton.addEventFilter(ActionEvent.ACTION, new TriangleButtonHandler(drawingPane));
        removeButton = new Button("Suppr.");
        removeButton.addEventFilter(ActionEvent.ACTION, new RemoveShapes(drawingPane));
        groupButton = new Button("Group");
        groupButton.addEventFilter(ActionEvent.ACTION, new GroupButtonHandler(drawingPane));
        degroupButton = new Button("Degroup");
        degroupButton.addEventFilter(ActionEvent.ACTION, new DegroupButtonHandler(drawingPane));
        getChildren().addAll(clearButton, rectangleButton, circleButton, triangleButton, removeButton, groupButton, degroupButton);
        setPadding(new Insets(5));
        setSpacing(5.0);
        getStyleClass().add("toolbar");
    }

    public void update () {

    }
}
