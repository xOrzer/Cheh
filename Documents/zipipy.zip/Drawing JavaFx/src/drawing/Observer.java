package drawing;

public interface Observer {
    public void update();
}
