package drawing;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import java.util.List;

public class RemoveShapes implements EventHandler<ActionEvent> {
    private DrawingPane drawingPane;

    public RemoveShapes(DrawingPane dpane)
    {
        drawingPane = dpane;
    }

    @Override
    public void handle(ActionEvent arg)
    {
        drawingPane.removeSelection();
    }
}
