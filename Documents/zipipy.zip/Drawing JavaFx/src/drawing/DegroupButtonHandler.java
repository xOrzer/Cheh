package drawing;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import java.util.ArrayList;

public class DegroupButtonHandler implements EventHandler<ActionEvent> {

    private DrawingPane drawingPane;

    public DegroupButtonHandler(DrawingPane dpane)
    {
        drawingPane = dpane;
    }


    @Override
    public void handle(ActionEvent event) {
        ArrayList<IShape> list = new ArrayList<IShape>();
        for (int i = 0; i < drawingPane.getSelection().size(); i++) {
            if(drawingPane.getSelection().get(i) instanceof Composite){
                Composite c = (Composite)drawingPane.getSelection().get(i);
                list = c.getList();
                System.out.println(list);
                drawingPane.removeShape(c);

                for (int j = 0; j < list.size(); j++) {
                    drawingPane.addShape(list.get(j));
                }
            }

        }

        drawingPane.getSelection().clear();
    }
}
