package drawing;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class GroupButtonHandler implements EventHandler<ActionEvent> {

    private DrawingPane drawingPane;

    public GroupButtonHandler(DrawingPane dpane)
    {
        drawingPane = dpane;
    }


    @Override
    public void handle(ActionEvent event) {

        Composite c = new Composite();

        for (int i = 0; i < drawingPane.getSelection().size(); i++) {
            c.add(drawingPane.getSelection().get(i));
        }

        drawingPane.removeSelection();

        drawingPane.addShape(c);
    }
}
